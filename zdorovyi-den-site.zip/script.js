function startTest() {
    document.getElementById('test-block').style.display = 'block';
}
function evaluateTest() {
    const hours = document.getElementById('sleep-hours').value;
    const result = document.getElementById('result');
    if (hours >= 7 && hours <= 9) {
        result.textContent = 'Ваш сон у нормі!';
    } else {
        result.textContent = 'Рекомендується спати 7-9 годин на добу.';
    }
}
